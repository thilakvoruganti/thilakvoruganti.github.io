import React from 'react';
import useScrollEffect from '../context/useScrollEffect';

const ExperienceCard = ({ edata }) => {
  const anim = useScrollEffect();

  return (
    <div
      data-js-controller={edata?.uid}
      className="expc r-transition"
      ref={anim.ref}
      style={{
        transform: `matrix(1, 0, 0, 1, 0, ${anim.style.transform})`,
        opacity: anim.style.opacity,
      }}
    >
      <div className='exp-card'>
        <p className='b-con'>
          {edata.points[1]}
        </p>
      </div>
    </div>
  );
};

export default ExperienceCard;
